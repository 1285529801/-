package com.liang.controller;

import com.liang.entity.Teacher;
import com.liang.service.TeacherService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin("*")
@RestController
public class TeacherController {
    public String TTno;
    public String TTname;
    @Autowired
    TeacherService teacherService;

    @GetMapping("/tea/all")
    @ResponseBody
    public List<Teacher> getTeacher(){return teacherService.getTeacher();}

    @GetMapping("/tea/login")
    @ResponseBody
    public String login(@RequestParam("tno") String tno ,@RequestParam("tname") String tname){
        String result ="-1";
        TTname =tname;
        TTno =tno;
        //=====判断======
        if(teacherService.login(tno,tname)==null){
            result="0";
        }
        else {
            result="1";
        }
        return result;
    }
    @GetMapping("/tea/information")
    @ResponseBody
    public List<Teacher> information(String Tno,String Tname){
        Tno =TTno;
        Tname =TTname;
        return teacherService.information(Tno, Tname);
    }


}
