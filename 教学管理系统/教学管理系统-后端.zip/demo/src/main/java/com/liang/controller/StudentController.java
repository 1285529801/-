package com.liang.controller;
import com.liang.entity.Student;
import com.liang.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@CrossOrigin("*")
@RestController
public class StudentController {
    public String SSno;
    public String SSname;
    @Autowired
    StudentService studentService;

    @GetMapping("/sa/stu")
    @ResponseBody
    public List<Student> getStudent(){return studentService.getStudent();}
//    ===========登录==========
    @GetMapping("/sa/login")
    @ResponseBody
    public String login(@RequestParam("sno") String sno ,@RequestParam("sname") String sname){
        String result ="-1";
        SSname = sname;
        SSno = sno;
        //=====判断======
        if(studentService.login(sno,sname)==null){
            result="0";
        }
        else {
            result="1";
        }
        return result;
    }
    @GetMapping("/sa/inform")
    @ResponseBody
    public List<Student> information(String Sno,String Sname){
        Sname=SSname;
        Sno= SSno;
        return studentService.information(Sno,Sname);
    }
    @GetMapping("/stu/tea")
    @ResponseBody
    public List<Student> getteacherstudent(@RequestParam("tname") String tname){
        return studentService.getteacherstudent(tname);
    }
}
