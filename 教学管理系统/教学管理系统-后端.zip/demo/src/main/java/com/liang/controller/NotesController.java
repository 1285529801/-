package com.liang.controller;

import com.liang.entity.Notes;
import com.liang.service.NotesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin("*")
@RestController
public class NotesController {
    @Autowired
    NotesService notesService;

    @GetMapping("/notes/add")
    @ResponseBody
    public void addnotes(@RequestParam("cno")String cno, @RequestParam("cname")String cname, @RequestParam("tno")String tno, @RequestParam("teacher")String teahcer, @RequestParam("period")String period, @RequestParam("classtime")String classtime, @RequestParam("classroom")String classroom){
        notesService.addnotes(cno, cname, tno, teahcer, period, classtime, classroom);
    }
    @GetMapping("/notes/del")
    @ResponseBody
    public void delnotes(@RequestParam("cno")String cno, @RequestParam("cname")String cname, @RequestParam("tno")String tno, @RequestParam("teacher")String teahcer, @RequestParam("period")String period, @RequestParam("classtime")String classtime, @RequestParam("classroom")String classroom){
        notesService.delnotes(cno, cname, tno, teahcer, period, classtime, classroom);
    }
    @GetMapping("/notes/update")
    @ResponseBody
    public void updatenotes(@RequestParam("cno")String cno, @RequestParam("cname")String cname, @RequestParam("tno")String tno, @RequestParam("teacher")String teahcer, @RequestParam("period")String period, @RequestParam("classtime")String classtime, @RequestParam("classroom")String classroom){
        notesService.updatenotes(cno, cname, tno, teahcer, period, classtime, classroom);
    }
    @GetMapping("/notes/all")
    @ResponseBody
    public List<Notes> getNotes(){
        return notesService.getNotes();
    }
    @GetMapping("/manager/approve")
    @ResponseBody
    public void approvue(@RequestParam("cno")String cno, @RequestParam("cname")String cname, @RequestParam("tno")String tno, @RequestParam("teacher")String teahcer, @RequestParam("period")String period, @RequestParam("classtime")String classtime, @RequestParam("classroom")String classroom,@RequestParam("state")String state){
        switch (state){
            case "想删除":
                notesService.delCourse(cno);
                notesService.delNotes(cno);
                break;
            case "想增加":
                notesService.insertCourse(cno,cname,tno,teahcer,period,classtime,classroom);
                notesService.delNotes(cno);
                break;
            case "想修改":
                notesService.updateCourse(cno,cname,tno,teahcer,period,classtime,classroom);
                notesService.delNotes(cno);
                break;
        }
    }
    @GetMapping("/manager/reject")
    @ResponseBody
    public void reject(@RequestParam("cno")String cno){
        notesService.delNotes(cno);
    }
}
