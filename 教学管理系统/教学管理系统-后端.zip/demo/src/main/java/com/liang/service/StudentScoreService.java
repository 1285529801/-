package com.liang.service;
import com.liang.dao.StudentScoreMapper;
import com.liang.entity.StudentScore;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class StudentScoreService {
    @Autowired
    StudentScoreMapper studentScoreMapper;
    public List<StudentScore> getBySnameMapper(String sname){
        return studentScoreMapper.getBySname(sname);
    }
}
