package com.liang.dao;

import com.liang.entity.Notes;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface NotesMapper {
    //增加课程信息请求
    @Insert("insert into notes values(#{cno},#{cname},#{teacher},#{tno},#{period},#{classtime},#{classroom},'想增加')")
    public void addnotes(@Param("cno")String cno,@Param("cname")String cname,@Param("tno")String tno,@Param("teacher")String teacher,@Param("period")String period,@Param("classtime")String classtime,@Param("classroom")String classroom);
    //删除课程信息请求
    @Insert("insert into notes values(#{cno},#{cname},#{teacher},#{tno},#{period},#{classtime},#{classroom},'想删除')")
    public void delnotes(@Param("cno")String cno,@Param("cname")String cname,@Param("tno")String tno,@Param("teacher")String teacher,@Param("period")String period,@Param("classtime")String classtime,@Param("classroom")String classroom);
    //修改课程信息请求
    @Insert("insert into notes values(#{cno},#{cname},#{teacher},#{tno},#{period},#{classtime},#{classroom},'想修改')")
    public void updatenotes(@Param("cno")String cno,@Param("cname")String cname,@Param("tno")String tno,@Param("teacher")String teacher,@Param("period")String period,@Param("classtime")String classtime,@Param("classroom")String classroom);
    //管理员查询所有请求信息
    @Select("select cno,cname,teacher,tno,period,classtime,classroom,state from notes")
    public List<Notes> getNotes();

    //同意增加信息
    @Insert("insert into course values(#{cno},#{cname},#{tno},#{teacher},#{period},#{classtime},#{classroom},'3')")
    public  void insertCourse(@Param("cno")String cno,@Param("cname")String cname,@Param("tno")String tno,@Param("teacher")String teacher,@Param("period")String period,@Param("classtime")String classtime,@Param("classroom")String classroom);

    //同意修改信息
    @Update("update course set cno=#{cno},cname=#{cname},tno=#{tno},teacher=#{teacher},period=#{period},classtime=#{classtime},classroom=#{classroom},state='3'")
    public  void updateCourse(@Param("cno")String cno,@Param("cname")String cname,@Param("tno")String tno,@Param("teacher")String teacher,@Param("period")String period,@Param("classtime")String classtime,@Param("classroom")String classroom);
    //同意删除信息
    @Delete("delete from course where cno=#{cno}")
    public  void delCourse(@Param("cno")String cno);
    //删除被审批的记录notes
    @Delete("delete from notes where cno=#{cno}")
    public  void delNotes(@Param("cno")String cno);
}
