package com.liang.service;

import com.liang.dao.TeacherMapper;
import com.liang.entity.Teacher;
import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TeacherService {
    @Autowired
    TeacherMapper teacherMapper;

    public List<Teacher> getTeacher(){return teacherMapper.getTeacher();}
    public String login(String tno, String tname){return teacherMapper.login(tno, tname);}
    public List<Teacher> information(String tno,String tname){return teacherMapper.information(tno, tname);}

}
