package com.liang.dao;

import com.liang.entity.Score;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

@Mapper
public interface ScoreMapper {
    @Update("update score set score.sscore=#{score} where sno=#{sno} and cno=#{cno}")
    public void insertscore(@Param("score")String score, @Param("sno")String sno, @Param("cno")String cno);

    @Select("select * from score")
    public List<Score> selectscore();
}
