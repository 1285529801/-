package com.liang.service;

import com.liang.dao.ScoreMapper;
import com.liang.entity.Score;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ScoreService {
    @Autowired
    ScoreMapper scoreMapper;

    public void insertscore(String score,String sno,String cno){
        scoreMapper.insertscore(score,sno,cno);
    }

    public List<Score> selectscore(){
        return scoreMapper.selectscore();
    }
}
