package com.liang.entity;

import lombok.Data;

@Data
public class Teacher {
    private String tno;
    private String tname;
    private String department;
    private String cname;
    private String cno;
}
