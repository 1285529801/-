package com.liang.entity;

import lombok.Data;

@Data

public class StudentScore {
    //private String sno;
    //private String cno;
    //private String tno;
    //private String sname;
    private String cname;
    private String tname;
    private double score;

}
