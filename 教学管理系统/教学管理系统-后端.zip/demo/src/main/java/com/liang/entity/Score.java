package com.liang.entity;

import lombok.Data;

@Data
public class Score {
    private String sno;
    private String cno;
    private String cname;
    private String sscore;
}
