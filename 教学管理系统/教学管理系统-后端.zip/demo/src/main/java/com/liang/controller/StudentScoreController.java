package com.liang.controller;

import com.liang.entity.StudentScore;
import com.liang.service.StudentScoreService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin("*")
@RestController
public class StudentScoreController {
    @Autowired
    StudentScoreService studentScoreService;
    @GetMapping("/studentscore")
    @ResponseBody
    public List<StudentScore> getBySnameService(@RequestParam("sname") String sname){
        return studentScoreService.getBySnameMapper(sname);
    }
}
