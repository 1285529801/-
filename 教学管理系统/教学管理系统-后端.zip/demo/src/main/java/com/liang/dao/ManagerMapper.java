package com.liang.dao;
import com.liang.entity.Manager;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import java.util.List;
@Mapper
public interface ManagerMapper {
    @Select("select * from user")
    public List<Manager> getManager();

    @Select("select id,password from user where id=#{id} and password=#{password}")
    public String login( @Param("id")String id , @Param("password")String password);


//    @Insert("insert into user(id,passwod) values(#{id},#{password},1)")
//    public int Adduser(Manager manager);
}
