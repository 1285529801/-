package com.liang.service;

import com.liang.dao.CourseSelectMapper;
import com.liang.entity.CourseSelect;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CourseSelectService {
    @Autowired
    CourseSelectMapper courseSelectMapper;

    public List<CourseSelect> getCourseSelect()
    {return courseSelectMapper.getCourseSelect();}
    public void CourseSelect(String sno,String cno){
        courseSelectMapper.CourseSelect(sno,cno);
    }
    public List<CourseSelect> Judge(String sno,String cno){
        return courseSelectMapper.Judge(sno, cno);
    }
    public void ScoreInsert(String sno,String cno,String cname){ courseSelectMapper.ScoreInsert(sno, cno, cname);}
    public void delselcourse(String sno,String cno){
        courseSelectMapper.delselcourse(sno,cno);
    }
}
