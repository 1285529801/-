package com.liang.entity;

import lombok.Data;

@Data
public class Notes {
    private String cname;
    private String cno;
    private String state;
    private String tno;
    private String teacher;
    private String period;
    private String classtime;
    private String classroom;
}
