package com.liang.dao;

import com.liang.entity.StudentScore;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface StudentScoreMapper {

//     学生成绩查询
    @Select("select course.cname,score,teacher.tname from student ,course,score,teacher where student.sno=score.sno and course.cno=score.cno  and course.tno=teacher.tno  and sname=#{sname}")
    public List<StudentScore> getBySname(@Param("sname") String sname);

}


