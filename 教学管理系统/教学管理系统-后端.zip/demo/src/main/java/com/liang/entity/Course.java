package com.liang.entity;

import lombok.Data;

@Data
public class Course {
    private String cno;
    private String cname;
    private String tno;
    private String teacher;
    private String period; //学分
    private String classtime; //学时
    private String classroom;
    private String state;
}
