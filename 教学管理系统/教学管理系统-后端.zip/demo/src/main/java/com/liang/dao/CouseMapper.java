package com.liang.dao;

import com.liang.entity.Course;

import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface CouseMapper {
    @Select("select * from course")
    public List<Course> getCourse();

    @Select("select course.cno,course.cname,course.teacher,course.classroom from course,student,course_select where student.sno=course_select.sno and course_select.cno= course.cno and student.sname=#{sname}")
    public List<Course> getmyCourse(@Param("sname")String sname);

    //教师新增课程
    @Insert("insert into course values(#{cno},#{cname},#{tno},#{teacher},#{period},#{classtime},#{classroom},'3')")
    public  void insertCourse(@Param("cno")String cno,@Param("cname")String cname,@Param("tno")String tno,@Param("teacher")String teacher,@Param("period")String period,@Param("classtime")String classtime,@Param("classroom")String classroom);

    //教师申请删除课程,并将状态码置为1；
    @Update("update course set state='1' where cname =#{cname}")
    public void deleteCourse(@Param("cname") String cname);
    //教师申请修改课程,并将状态码置为2
    @Update("update course set tno ='t011' where cno= 'b006'")
    public void updateCourse();

    @Select("select classtime,classroom,cname,teacher from course")
    public List<Course> fenCourse();
}
