package com.liang.service;
import com.liang.dao.ManagerMapper;
import com.liang.entity.Manager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ManagerService {
    @Autowired
    ManagerMapper managerMapper;

    public List<Manager> getManagerMapper(){
        return managerMapper.getManager();
    }
    public String login(String id ,String password){return managerMapper.login( id,password);}
//    public int Adduser(Manager manager){return managerMapper.Adduser(manager);}
}
