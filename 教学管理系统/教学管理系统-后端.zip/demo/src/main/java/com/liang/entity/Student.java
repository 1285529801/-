package com.liang.entity;

import lombok.Data;

@Data
public class Student {
    private String sno;
    private String sname;
    private String classes;
}
