package com.liang.entity;

import lombok.Data;

@Data
public class Manager {
    private String id;
    private String password;
    private String authority;


}

