package com.liang.controller;
import com.liang.entity.Manager;
import com.liang.service.ManagerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin("*")
@RestController
public class MnagerController {
    @Autowired
    ManagerService managerService;

    @GetMapping("/manger/all")
    @ResponseBody
    public List<Manager> getAll(){
        return managerService.getManagerMapper();
    }
//=========登录==============
    @GetMapping("/manger/login")
    @ResponseBody
    public String login(@RequestParam("id") String id ,@RequestParam("password") String password){

        System.out.println(id + password);
        String result ="-1";
        //=====判断======
        if(managerService.login(id,password)==null){
            result="0";
        }
        else {
            result="1";
        }
        return result;


    }
//    @GetMapping("/add")
//    public int Adduser(@RequestBody Manager manager){return managerService.Adduser(manager);}
    @GetMapping("/a")
    public String test(){
        return "Test my project";
    }
}
