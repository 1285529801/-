package com.liang.controller;

import com.liang.entity.Score;
import com.liang.service.ScoreService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin("*")
@RestController
public class ScoreController {
    @Autowired
    ScoreService scoreService;

    @GetMapping("/interscore")
    @ResponseBody
    public void insertscore(@RequestParam("score")String score, @RequestParam("sno")String sno, @RequestParam("cno")String cno){
        scoreService.insertscore(score, sno, cno);
    }

    @GetMapping("/student/sscore")
    @ResponseBody
    public List<Score> selectscore(){
        return scoreService.selectscore();
    }
}
