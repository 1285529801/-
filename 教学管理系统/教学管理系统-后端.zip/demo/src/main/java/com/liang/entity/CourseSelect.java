package com.liang.entity;

import lombok.Data;

@Data
public class CourseSelect {
    private String cno;
    private String sno;
}
