package com.liang.dao;

import com.liang.entity.CourseSelect;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface CourseSelectMapper {
    @Select("select * from course_select")
    public List<CourseSelect> getCourseSelect();

    @Select("select * from course_select where sno=#{sno} and con=#{cno}")
    public List<CourseSelect> Judge(@Param("sno")String sno, @Param("cno")String cno);

    @Insert("insert into course_select(cno,sno) values(#{cno},#{sno})")
    public void CourseSelect(@Param("sno")String sno, @Param("cno")String cno);

    @Insert("insert into score(cno,sno,cname) values(#{cno},#{sno},#{cname})")
    public void ScoreInsert(@Param("sno") String sno, @Param("cno") String cno, String cname);

    //学生退选课程
    @Delete("delete from course_select where sno=#{sno} and cno=#{cno}")
    public void delselcourse(@Param("sno") String sno,@Param("cno") String cno);


}
