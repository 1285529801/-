package com.liang.dao;

import com.liang.entity.Teacher;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

@Mapper
public interface TeacherMapper {
    @Select("select * from teacher")
    public List<Teacher> getTeacher();

    @Select("select tno,tname from teacher where tno=#{tno} and tname=#{tname}")
    public String login(@Param("tno")String tno , @Param("tname")String tname);

    @Select("select * from teacher where tno=#{Tno} and tname=#{Tname}")
    public List<Teacher> information(@Param("Tno")String tno, @Param("Tname")String tname);


}
