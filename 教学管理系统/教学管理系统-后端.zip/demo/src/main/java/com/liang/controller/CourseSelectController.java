package com.liang.controller;

import com.liang.entity.CourseSelect;
import com.liang.service.CourseSelectService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin("*")
@RestController
public class CourseSelectController {
    @Autowired
    CourseSelectService courseSelectService;

    @GetMapping("/course/sc")
    @ResponseBody
    public List<CourseSelect> getAll()
    {return courseSelectService.getCourseSelect();}

    @GetMapping("/course/select")
    @ResponseBody
    public void CourseSelect(@RequestParam("sno") String sno , @RequestParam("cno") String cno,@RequestParam("cname") String cname){
        courseSelectService.CourseSelect(sno, cno);
        courseSelectService.ScoreInsert(sno,cno,cname);
    }
    @GetMapping("/course/tui")
    @ResponseBody
    public void delselcourse(@RequestParam("sno") String sno,@RequestParam("cno") String cno){
        courseSelectService.delselcourse(sno,cno);
    }
}

