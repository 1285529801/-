package com.liang.service;
import com.liang.dao.CouseMapper;
import com.liang.entity.Course;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class CourseService {
    @Autowired
    CouseMapper couseMapper;

    public List<Course> getCouseMapper(){
        return couseMapper.getCourse();
    }
    public List<Course> getmyCourse(String sname){
        return couseMapper.getmyCourse(sname);
    }
    public  void insertCourse(String cno,String cname,String tno,String teacher,String period,String classtime,String classroom){
        couseMapper .insertCourse(cno, cname, tno, teacher, period, classtime, classroom);
    }
    public void deleteCourse(String cname){
        couseMapper.deleteCourse(cname);
    }
    public List<Course> fenCourse(){return couseMapper.fenCourse();}
}
