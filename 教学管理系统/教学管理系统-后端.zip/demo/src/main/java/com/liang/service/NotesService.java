package com.liang.service;

import com.liang.dao.NotesMapper;
import com.liang.entity.Notes;
import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class NotesService {
    @Autowired
    NotesMapper notesMapper;

    public void addnotes(String cno,String cname,String tno,String teacher,String period,String classtime,String classroom){
        notesMapper.addnotes(cno, cname, tno, teacher, period, classtime, classroom);
    }
    public void delnotes(String cno,String cname,String tno,String teacher,String period,String classtime,String classroom){
        notesMapper.delnotes(cno, cname, tno, teacher, period, classtime, classroom);
    }
    public void updatenotes(String cno,String cname,String tno,String teacher,String period,String classtime,String classroom){
        notesMapper.updatenotes(cno, cname, tno, teacher, period, classtime, classroom);
    }
    public List<Notes> getNotes(){
        return notesMapper.getNotes();
    }
    public  void insertCourse(String cno,String cname,String tno,String teacher,String period,String classtime,String classroom){
        notesMapper.insertCourse(cno, cname, tno, teacher, period, classtime, classroom);
    }
    public  void updateCourse(String cno,String cname,String tno,String teacher,String period,String classtime,String classroom){
        notesMapper.updateCourse(cno, cname, tno, teacher, period, classtime, classroom);
    }
    public  void delCourse(String cno){
        notesMapper.delCourse(cno);
    }
    public  void delNotes(String cno){
        notesMapper.delNotes(cno);
    }
}
