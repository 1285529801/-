package com.liang.dao;
import com.liang.entity.Student;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import java.util.List;
@Mapper
public interface StudentMapper {
    @Select("select * from student")
    public List<Student> getStudent();

    @Select("select sno,sname from student where sno=#{sno} and sname=#{sname}")
    public String login(@Param("sno")String sno, @Param("sname")String sname);

    @Select("select * from student where sno=#{Sno} and sname=#{Sname}")
    public List<Student> information(@Param("Sno")String sno, @Param("Sname")String sname);

    @Select("select student.sno,student.sname,student.classes from student,course,course_select where student.sno=course_select.sno and course_select.cno=course.cno and teacher=#{tname}")
    public List<Student> getteacherstudent(@Param("tname")String tname);
}
