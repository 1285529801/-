package com.liang.service;
import com.liang.dao.StudentMapper;
import com.liang.entity.Student;
import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class StudentService {
    @Autowired
    StudentMapper studentMapper;

    public List<Student> getStudent(){return studentMapper.getStudent();}
    public String login(String sno, String sname){return studentMapper.login(sno, sname);}
    public List<Student> information(String sno, String sname){return studentMapper.information(sno, sname);}
    public List<Student> getteacherstudent(String tname){return studentMapper.getteacherstudent(tname);}
}
