package com.liang.controller;

import com.liang.entity.Course;
import com.liang.service.CourseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin("*")
@RestController
public class CourseContrller {
    @Autowired
    CourseService courseService;

    @GetMapping("/course/all")
    @ResponseBody
    public List<Course> getCourse(){
        return courseService.getCouseMapper();
    }
    @GetMapping("/course/fen")
    @ResponseBody
    public List<Course> fenCourse(){
        return courseService.fenCourse();
    }
    @GetMapping("/course/mycourse")
    @ResponseBody
    public List<Course> getmyCourse(@RequestParam("sname") String sname){
        return courseService.getmyCourse(sname);
    }
    @GetMapping("/course/intercourse")
    @ResponseBody
    public  void insertCourse(@RequestParam("cno")String cno, @RequestParam("cname")String cname, @RequestParam("tno")String tno, @RequestParam("teahcer")String teahcer, @RequestParam("period")String period, @RequestParam("classtime")String classtime, @RequestParam("classroom")String classroom){
        courseService.insertCourse(cno, cname, tno, teahcer, period, classtime, classroom);
    }
    @GetMapping("/course/delete")
    @ResponseBody
    public void deleteCourse(@RequestParam("cname") String cname){
        courseService.deleteCourse(cname);
    }
}
