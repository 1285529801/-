<template>
  <div id="teacher">
    teacher
  </div>
</template>

<script>
export default {
  name: 'Teacher'
}
</script>

<style scoped>

</style>
