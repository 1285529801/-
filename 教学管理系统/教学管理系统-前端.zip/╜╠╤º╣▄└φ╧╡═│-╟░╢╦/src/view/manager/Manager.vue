<template>
  <div id="manager">
    manager
  </div>
</template>

<script>
export default {
  name: 'Manager'
}
</script>

<style scoped>

</style>
