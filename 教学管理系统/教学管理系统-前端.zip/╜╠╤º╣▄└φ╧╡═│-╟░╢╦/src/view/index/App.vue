<template>
  <div id="app">

  </div>


</template>

Vue.config.productionTip = false
Vue.prototype.$http= axios
axios.defaults.baseURL = "/api"
Vue.config.productionTip = false

<script>
import Main from '../../components/Web/Main.vue'
import Top from '../../components/Web/Top.vue'
export default {
  name: 'App',
  comments:{
    Main,
    Top
  }
}
</script>

<style>
*{
  body: 100%;
  padding: 0px;
  margin: 0px;
}

</style>
