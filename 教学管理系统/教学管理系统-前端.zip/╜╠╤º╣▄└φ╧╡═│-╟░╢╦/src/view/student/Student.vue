<template>
  <div id="student">
    student
  </div>
</template>

<script>
export default {
  name: 'Student'
}
</script>

<style scoped>

</style>
