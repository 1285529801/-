<template>

  <loginSelect></loginSelect>
</template>

<script>
import loginSelect from '../../components/Login/Login-select'
export default {
  name: 'Login',
  comments:{
    loginSelect
  }
}
</script>

<style scoped>

</style>
