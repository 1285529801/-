import Vue from 'vue'
import MainTeacher from './components/Teacher/Main-teacher'
import router from './router'
import './plugins/axios'
import 'element-ui/lib/theme-chalk/index.css';
import './plugins/element.js'
import './assets/CSS/global.css'
import Router from 'vue-router'

Vue.use(Router)
Vue.prototype.$http= axios
axios.defaults.baseURL = "/api"
Vue.config.productionTip = false

new Vue({
  el: '#teacher',
  router,
  components: {MainTeacher},
  template: '<MainTeacher/>'
})
