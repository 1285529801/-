import Vue from 'vue'
import login from './view/login/Login.vue'
import router from './router'
import App from './view/index/App'

Vue.prototype.$http= axios
axios.defaults.baseURL = "/api"
Vue.config.productionTip = false

new Vue({
  el: '#login',
  router,
  components: {login},
  template: '<login/>'
})
