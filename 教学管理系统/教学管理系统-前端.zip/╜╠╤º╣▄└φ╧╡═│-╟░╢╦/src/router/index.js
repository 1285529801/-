import Vue from 'vue'
import Router from 'vue-router'
import LoginManager from '../components/Login/Login-manager.vue'
import LoginStudent from '../components/Login/Login-student.vue'
import LoginTeahcer from '../components/Login/Login-teahcer.vue'
import RightStudentscore from '../components/Student/Right-studentscore'
import RightStudentselec from '../components/Student/Right-studentselec'
import RightTeacherCoursemg from '../components/Teacher/Right-teacher-coursemg'
import RightTeacherCourseset from '../components/Teacher/Right-teacher-courseset'
import RightStudenttable from '../components/Student/Right-studenttable'
import RightManagerarg from '../components/Manager/Right-managerargfen'
import RightManagerset from '../components/Manager/Right-managerset'
import RightManagerargkcb from '../components/Manager/Right-managerargkcb'
import RightManagerargsc from '../components/Manager/Right-managerargsc'
import RightManagerargxkjg from '../components/Manager/Right-managerargxkjg'
import RightManagerargfen from '../components/Manager/Right-managerargfen'

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      redirect:"/App"
    },
    {
      path: '/Login-manager',
      name: '管理员登录',
      component: LoginManager //不能加单、双引号
    },
    {
      path: '/Login-teacher',
      name: '教师登录',
      component: LoginTeahcer
    },
    {
      path: '/Login-student',
      name: '学生登录',
      component: LoginStudent
    },
    {
      path: '/RightStudentscore',
      name: '学生成绩',
      component: RightStudentscore
    },
    {
      path: '/RightStudentselec',
      name: '学生选课',
      component: RightStudentselec
    },
    {
      path: '/RightTeacherCoursemg',
      name: '课程管理',
      component: RightTeacherCoursemg
    },
    {
      path: '/RightTeacherCourseset',
      name: '课程设置',
      component: RightTeacherCourseset
    },
    {
      path: '/RightStudenttable',
      name: '学生课表',
      component:RightStudenttable
    },
    {
      path: '/RightManagerarg',
      name: '教学安排',
      component:RightManagerarg
    },
    {
      path: '/RightManagerset',
      name: '课程设置审批',
      component:RightManagerset
    },
    {
      path: '/RightManagerargkcb',
      name: '课程表报表',
      component:RightManagerargkcb
    },
    {
      path: '/RightManagerargsc',
      name: '成绩单生成',
      component:RightManagerargsc
    },{
      path: '/RightManagerargxkjg',
      name: '选课结果管理',
      component:RightManagerargxkjg
    },
    {
      path: '/RightManagerargfen',
      name: '时间和教师分配',
      component:RightManagerargfen
    },

  ]
})
