<template>
  <div class="content_right">
    <div class="control_right_top">
      <div style="position: relative;top:15px;left: 15px">
        <h3>总课程表</h3>
      </div>
      <hr style="width: 100%;margin-top: 70px">
    </div>
    <el-dialog title="学生成绩单" >

    </el-dialog>

    <div class="content_table">
      <el-table :data="course" height="560">
        <el-table-column property="cno" label="课程号" width="210"></el-table-column>
        <el-table-column property="cname" label="课程名" width="210"></el-table-column>
        <el-table-column property="tno" label="教师工号" width="210"></el-table-column>
        <el-table-column property="teacher" label="任课老师"></el-table-column>
        <el-table-column property="period" label="学时"></el-table-column>
        <el-table-column property="classtime" label="上课时间"></el-table-column>
        <el-table-column property="classroom" label="上课地点"></el-table-column>
      </el-table>

    </div>
  </div>
</template>

<script>
import axios from 'axios'

export default {
  name: 'Right-managerargkcb',
  data(){
    return{
      course: [],
    }
  },
  created (){
    this.getUserCourse()
  },
  methods:{
    getUserCourse () {
      axios.get("http://192.168.43.154:8082/course/all").then(response => {
        this.course = response.data
        console.log(this.course)
      })
        .catch(error => {
        })
    },
  }
}
</script>

<style scoped>
.content_right{
  width: 1344px;
  height: 660px;
  position: absolute;
  left: 190px;
  top: 85px;
}
.control_right_top{
  width: 1300px;
  height: 60px;
  margin-bottom: -10px;
  /*border: 1px solid black;*/
}
.content_table table{
  width: 1200px;
  height: 500px;
  text-align: center;
  margin-left: 80px;
  /*border: 1px solid black;*/
}
</style>
