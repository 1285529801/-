<template>
  <div class="content_right">
    <div class="control_right_top">
      <div style="position: relative;top:15px;left: 10px">
        <el-button type="primary" @click="dialogTableVisible = true;getStudentScore">打印学生的成绩单</el-button>
      </div>
      <hr style="width: 100%;margin-top: 70px">
    </div>
    <el-dialog title="学生成绩单" :visible.sync="dialogTableVisible">
      <el-table :data="studentscore">
        <el-table-column property="sno" label="学号" width="210"></el-table-column>
        <el-table-column property="cno" label="课程号" width="210"></el-table-column>
        <el-table-column property="cname" label="课程名" width="210"></el-table-column>
        <el-table-column property="sscore" label="成绩"></el-table-column>
      </el-table>
    </el-dialog>

    <div class="content_table">
      <el-table :data="student" height="560">
        <el-table-column property="" label="" width="110"></el-table-column>
        <el-table-column property="sno" label="学号" width="410"></el-table-column>
        <el-table-column property="sname" label="姓名" width="510"></el-table-column>
        <el-table-column property="classes" label="班级" width="260"></el-table-column>

      </el-table>

    </div>
  </div>
</template>

<script>
import axios from 'axios'

export default {
  name: 'Right-managerargsc',
  data() {
    return {
      student: [],
      studentscore:[],
      dialogTableVisible:false,
    }
  },
  created(){//页面渲染之前执行，调用定义的方法
    //3.调用定义的方法
    this.getUserStudent()
    this.getStudentScore();
  },
  methods:{//编写具体的方法
    getUserStudent(){
      //2.使用axios发送ajax请求
      //axios.提交方式(“请求s接口路径”).then(箭头函数).catch(箭头函数|)
      axios.get("http://192.168.43.154:8082/sa/stu")
        .then(response=>{
          //response就是请求后返回的数据，response可以任意取名
          // console.log(response)
          //通过response获取具体数据，赋值给定义空数组
          this.student=response.data
          console.log(this.student)

        })//请求成功执行then方法
        .catch(error=>{

        })//请求失败执行catch方法
    },
    getStudentScore(){
      axios.get("http://192.168.43.154:8082/student/sscore")
        .then(response=>{
          this.studentscore=response.data
          console.log(this.studentscore)
        })
        .catch(error=>{

        })//请求失败执行catch方法
    },
  }
}
</script>

<style scoped>
.content_right{
  width: 1340px;
  height: 650px;
  position: absolute;
  left: 190px;
  top: 85px;
  /*border: 1px solid black;*/
}
.control_right_top{
  width: 1335px;
  height: 60px;
  margin-bottom: -10px;
  /*border: 1px solid black;*/
}
.content_table table{
  width: 1200px;
  height: 520px;
  text-align: center;
  margin-left: 80px;
  margin-top: 8px;
  /*border: 1px solid black;*/
}
</style>

