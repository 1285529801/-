<template>
  <div class="content_right">
    <div class="control_right_top">
      <div style="position: relative;top:15px;left: 15px">
        <h3>总学生选课表</h3>
      </div>
      <hr style="width: 100%;margin-top: 70px">
    </div>

    <div class="content_table">
      <el-table :data="courseselect" height="560">
        <el-table-column property="" label="" width="410"></el-table-column>
        <el-table-column property="cno" label="课程号" width="510"></el-table-column>
        <el-table-column property="sno" label="学号" width="390"></el-table-column>

      </el-table>

    </div>
  </div>
</template>

<script>
import axios from 'axios'

export default {
  name: 'Right-managerargxkjg',
  data(){
    return{
      courseselect: [],
    }
  },
  created (){
    this.getUserCourse()
  },
  methods:{
    getUserCourse () {
      axios.get("http://192.168.43.154:8082/course/sc").then(response => {
        this.courseselect = response.data
        console.log(this.courseselect)
      })
        .catch(error => {
        })
    },
  },
}
</script>

<style scoped>
.content_right{
  width: 1344px;
  height: 660px;
  position: absolute;
  left: 190px;
  top: 85px;
}
.control_right_top{
  width: 1330px;
  height: 60px;
  margin-bottom: -10px;
  /*border: 1px solid black;*/
}
.content_table table{
  width: 1200px;
  height: 500px;
  text-align: center;
  margin-left: 80px;
  /*border: 1px solid black;*/
}
</style>
