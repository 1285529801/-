<template>
  <div class="head">
    <div class="head-left">
      <p>教学管理系统</p>
    </div>
    <div class="head-right">

      <el-button type="text" @click="dialogTableVisible = true">个人中心</el-button>
      <a href="index.html">
        <el-button type="text">退出</el-button>
      </a>
      <!--    ================个人信息==================-->
      <el-dialog title="个人信息" :visible.sync="dialogTableVisible">
        <el-descriptions title="我的信息">
          <el-descriptions-item label="学号">{{manager[0].id}}</el-descriptions-item>
          <el-descriptions-item label="姓名">{{manager[0].password}}</el-descriptions-item>


        </el-descriptions>
      </el-dialog>

    </div>
  </div>
</template>

<script>
import axios from 'axios'

export default {
  name: 'Manager-top',
  data() {
    return {
      manager: [],
      dialogTableVisible: false,
    }
  },
  created(){//页面渲染之前执行，调用定义的方法
    //3.调用定义的方法
    this.getUser()
  },
  methods:{
    getUser(){
      //2.使用axios发送ajax请求
      //axios.提交方式(“请求s接口路径”).then(箭头函数).catch(箭头函数|)
      axios.get("http://192.168.43.154:8082/manger/all")
        .then(response=>{
          //response就是请求后返回的数据，response可以任意取名
          // console.log(response)
          //通过response获取具体数据，赋值给定义空数组
          this.manager=response.data
          console.log(this.manager)
        })//请求成功执行then方法
        .catch(error=>{
        })//请求失败执行catch方法
    }
  }
}
</script>

<style scoped>
*{
  padding: 10px;
  margin: -5px;
}
.head{
  height: 65px;
  width: 98.7%;
  margin: 0;
  background-image: linear-gradient(to bottom, #9db6ea,lightskyblue);
}
.head-left{
  height: 45px;
  width: 400px;
  margin-left: 20px;
  font-family: "Hiragino Sans GB",serif;
  font-size: 29px;
  /*border: 1px solid black;*/
}
.head-right{
  width: 185px;
  padding-top: 25px;
  padding-left: 25px;
  height: 50px;
  float: right;
  /*border: 1px solid black;*/
  margin-top: -65px;
  margin-right: -10px;
  background-image: linear-gradient(to top, #efe9e9, #f8f7f7);
}
</style>
