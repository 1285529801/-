<template>

</template>

<script>
export default {
  name: 'Manager-right'
}
</script>

<style scoped>

</style>
