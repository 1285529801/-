<template>
  <div>
    <topManager></topManager>
    <leftManager></leftManager>
    <rightManager></rightManager>
    <transition>
      <keep-alive>
        <router-view></router-view>
      </keep-alive>
    </transition>
  </div>
</template>

<script>
import topManager from './Top-manager'
import leftManager from './Left-manager'
import rightManager from './Right-manager'
import RightManagerarg from './Right-managerargfen'
import RightManagerset from './Right-managerset'
import RightManagerargfen from './Right-managerargfen'
import RightManagerargkcb from './Right-managerargkcb'
import RightManagerargxkjg from './Right-managerargxkjg'
import RightManagerargsc from './Right-managerargsc'
export default {
  name: 'Main-manager',
  components:{
    topManager,
    leftManager,
    rightManager,
    RightManagerarg,
    RightManagerset,
    RightManagerargfen,
    RightManagerargkcb,
    RightManagerargxkjg,
    RightManagerargsc
  }
}
</script>

<style scoped>

</style>
