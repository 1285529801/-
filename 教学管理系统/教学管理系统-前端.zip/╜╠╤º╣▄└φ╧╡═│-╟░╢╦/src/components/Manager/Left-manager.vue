<template>
  <div class="content-left">
    <el-col :span="24">
      <el-menu
        default-active="2"
        class="el-menu-vertical-demo"
        @open="handleOpen"
        @close="handleClose">
        <router-link to="/RightManagerset">
          <el-menu-item index="1">
            <i class="el-icon-menu"></i>
            <span slot="title">课程设置审批</span>
          </el-menu-item>
        </router-link>

        <el-submenu index="2">
          <template slot="title">
            <i class="el-icon-location"></i>
            <span>教学安排</span>
          </template>
          <el-menu-item-group>

            <router-link to="/RightManagerargfen">
              <el-menu-item index="1-1">时间和教室分配</el-menu-item>
            </router-link>

            <router-link to="/RightManagerargkcb">
              <el-menu-item index="1-2">课程表安排报表</el-menu-item>
            </router-link>

            <router-link to="/RightManagerargxkjg">
              <el-menu-item index="1-3">选课结果管理</el-menu-item>
            </router-link>

            <router-link to="/RightManagerargsc">
              <el-menu-item index="1-4">成绩单生成</el-menu-item>
            </router-link>
          </el-menu-item-group>
        </el-submenu>
      </el-menu>
    </el-col>
  </div>
</template>

<script>
export default {
  name: 'Manager-left'
}
</script>

<style scoped>
.content-left{
  width: 190px;
  height: 667px;
  background-image: linear-gradient(to right, #9db6ea,lightskyblue);
}
a {
  text-decoration: none;
}
</style>
