<template>
  <div class="content_right">
    <div class="control_right_top">
      <h2 style="margin-left: 30px">待处理的请求</h2>
      <hr style="width: 100%;margin-top: 56px">
    </div>
    <div class="content_right_content">
    </div>

    <div class="content_table">
      <el-table :data="notes" height="560" :row-class-name="tableRowClassName">
        <el-table-column property="" label="" width="60"></el-table-column>
        <el-table-column property="cno" label="课程号" width="120"></el-table-column>
        <el-table-column property="cname" label="课程名" width="120"></el-table-column>
        <el-table-column property="teacher" label="任课老师" width="120"></el-table-column>
        <el-table-column property="tno" label="教师工号" width="120"></el-table-column>
        <el-table-column property="period" label="学分" width="120"></el-table-column>
        <el-table-column property="classtime" label="上课时间" width="120"></el-table-column>
        <el-table-column property="classroom" label="上课地点" width="120"></el-table-column>
        <el-table-column property="state" label="请求类型" width="160"></el-table-column>
        <el-table-column label="批准" width="100">
          <template slot-scope="scope">
            <el-button type="success" icon="el-icon-check" circle  @click.native.prevent="approve(scope.row)"></el-button>
          </template>
        </el-table-column>
        <el-table-column label="驳回" width="160" >
          <template slot-scope="scope">
            <el-button type="danger" icon="el-icon-delete" circle @click.native.prevent="reject(scope.row)"></el-button>
          </template>
        </el-table-column>
      </el-table>

    </div>
  </div>
</template>

<script>
import axios from 'axios'

export default {
  name: 'Right-managerset',
  data() {
    return {
      notes: [],
      index:'',
    }
  },
  created(){//页面渲染之前执行，调用定义的方法
    //3.调用定义的方法
    this.getNotes()
  },
  methods:{//编写具体的方法
    getNotes(){
      //2.使用axios发送ajax请求
      //axios.提交方式(“请求s接口路径”).then(箭头函数).catch(箭头函数|)
      axios.get("http://192.168.43.154:8082/notes/all")
        .then(response=>{
          //response就是请求后返回的数据，response可以任意取名
          // console.log(response)
          //通过response获取具体数据，赋值给定义空数组
          this.notes=response.data
          console.log(this.notes)

        })//请求成功执行then方法
        .catch(error=>{

        })//请求失败执行catch方法
    },
    //同意
    approve(row){
      console.log('被点击了');
      this.index = row.row_index;
      console.log(row);
      console.log(this.index);
      axios.get("http://192.168.43.154:8082/manager/approve",{
        params:{
           cno:this.notes[this.index].cno,
           cname:this.notes[this.index].cname,
           period:this.notes[this.index].period,
           classtime:this.notes[this.index].classtime,
           classroom:this.notes[this.index].classroom,
           teacher:this.notes[this.index].teacher,
           tno:this.notes[this.index].tno,
           state:this.notes[this.index].state,
    }
      })
        .then(response=>{
          //response就是请求后返回的数据，response可以任意取名
          // console.log(response)
          //通过response获取具体数据，赋值给定义空数组
          this.notes=response.data
          console.log(this.notes)
          alert("批准成功")
          window.location.href='manager.html'
        })//请求成功执行then方法
        .catch(error=>{

        })//请求失败执行catch方法
    },
    //驳回
    reject(row){
      console.log('被点击了');
      this.index = row.row_index;
      console.log(row);
      console.log(this.index);
      //2.使用axios发送ajax请求
      //axios.提交方式(“请求s接口路径”).then(箭头函数).catch(箭头函数|)
      axios.get("http://192.168.43.154:8082/manager/reject",{
        params:{
          cno:this.notes[this.index].cno,
        },

      })
        .then(response=>{
          //response就是请求后返回的数据，response可以任意取名
          // console.log(response)
          //通过response获取具体数据，赋值给定义空数组
          this.notes=response.data
          console.log(this.notes)
          alert("驳回成功")
          window.location.href='manager.html'
        })//请求成功执行then方法
        .catch(error=>{

        })//请求失败执行catch方法
    },
    tableRowClassName({row, rowIndex}) {
      row.row_index = rowIndex;
    },

  }
}
</script>


<style scoped>
.content_right{
  width: 1344px;
  height: 660px;
  position: absolute;
  left: 190px;
  top: 85px;
}
.control_right_top{
  width: 1344px;
  height: 60px;
  margin-bottom: -10px;
  /*border: 1px solid black;*/
}
.content_table table{
  width: 1200px;
  height: 500px;
  text-align: center;
  margin-left: 80px;
  /*border: 1px solid black;*/
}
</style>
