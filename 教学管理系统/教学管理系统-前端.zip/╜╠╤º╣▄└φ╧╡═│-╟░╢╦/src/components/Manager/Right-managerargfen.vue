<template>
  <div class="content_right">
    <div class="control_right_top">
      <div style="position: relative;top:15px;left: 15px">
        <h3>时间和教室分配</h3>
      </div>
      <hr style="width: 100%;margin-top: 70px">
    </div>


    <div class="content_table">
      <el-table :data="course" height="560">
        <el-table-column property="cname" label="课程名" width="410"></el-table-column>
        <el-table-column property="teacher" label="任课老师" width="400"></el-table-column>
        <el-table-column property="classtime" label="上课时间" width="400"></el-table-column>
        <el-table-column property="classroom" label="上课地点"></el-table-column>
      </el-table>

    </div>
  </div>
</template>

<script>
import axios from 'axios'

export default {
  name: 'Right-managerarg',
  data() {
    return {
      course: [],
    }
  },
  created(){//页面渲染之前执行，调用定义的方法
    //3.调用定义的方法
    this.getFen()
  },
  methods:{//编写具体的方法
    getFen(){
      //2.使用axios发送ajax请求
      //axios.提交方式(“请求s接口路径”).then(箭头函数).catch(箭头函数|)
      axios.get("http://192.168.43.154:8082/course/fen")
        .then(response=>{
          //response就是请求后返回的数据，response可以任意取名
          // console.log(response)
          //通过response获取具体数据，赋值给定义空数组
          this.course=response.data
          console.log(this.course)

        })//请求成功执行then方法
        .catch(error=>{

        })//请求失败执行catch方法
    }
  }
}
</script>


<style scoped>
.content_right{
  width: 1344px;
  height: 660px;
  position: absolute;
  left: 190px;
  top: 85px;
}
.control_right_top{
  width: 1330px;
  height: 60px;
  margin-bottom: -10px;
  /*border: 1px solid black;*/
}
.content_table table{
  width: 1200px;
  height: 500px;
  text-align: center;
  margin-left: 80px;
  /*border: 1px solid black;*/
}
</style>
