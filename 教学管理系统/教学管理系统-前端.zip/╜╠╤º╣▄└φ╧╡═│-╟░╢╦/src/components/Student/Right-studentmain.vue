<template>
  <div class="content_right">
    <div class="control_right_top">
      <h2 style="margin-left: 30px">学生信息</h2>
      <hr style="width: 100%;margin-top: 56px">
    </div>

    <div class="content_table">

    </div>
  </div>
</template>

<script>
import axios from 'axios'

export default {
  name: 'Right-student',
  data() {
    return {
      student: [],
    }
  },
  created(){//页面渲染之前执行，调用定义的方法
    //3.调用定义的方法
    this.getUserStudent()
  },
  methods:{//编写具体的方法
    getUserStudent(){
      //2.使用axios发送ajax请求
      //axios.提交方式(“请求s接口路径”).then(箭头函数).catch(箭头函数|)
      axios.get("http://192.168.43.154:8082/sa/stu")
        .then(response=>{
          //response就是请求后返回的数据，response可以任意取名
          // console.log(response)
          //通过response获取具体数据，赋值给定义空数组
          this.student=response.data
          console.log(this.student)

        })//请求成功执行then方法
        .catch(error=>{

        })//请求失败执行catch方法
    }
  }
}
</script>

<style scoped>
.content_right{
  width: 1344px;
  height: 660px;
  position: absolute;
  left: 190px;
  top: 85px;
}
.control_right_top{
  width: 1344px;
  height: 60px;
  margin-bottom: -10px;
  /*border: 1px solid black;*/
}
.content_table table{
  width: 1200px;
  height: 500px;
  text-align: center;
  margin-left: 80px;
  /*border: 1px solid black;*/
}
</style>
