<template>
  <div class="content_right">
    <div class="control_right_top">
      <div style="margin-top: 15px;margin-left: 20px">

        <el-button type="primary" @click="dialogTableVisible = true">查询成绩</el-button>

        <el-dialog title="我的成绩" :visible.sync="dialogTableVisible">
          <el-button type="primary" @click="getStudentScore" >查询我的成绩</el-button>
          <el-table :data="score">
            <el-table-column property="cname" label="课程名" width="200"></el-table-column>
            <el-table-column property="tname" label="任课老师" width="420"></el-table-column>
            <el-table-column property="score" label="成绩"></el-table-column>
          </el-table>
        </el-dialog>

      </div>
      <hr style="width: 100%;margin-top: 113px">
    </div>


  </div>
</template>

<script>
import axios from 'axios'
export default {
  name: 'Right-studentscore',
  data () {
    return {
      score: [],
      information:[],
      dialogTableVisible: false,
      dialogFormVisible: false,
      form: {
        id:'',
        name: '',
        teahcer:'',
        period:'',
        classtime:'',
        classroom:'',
        region: '',
      },
      formLabelWidth: '120px'
    }
  },
  created () {//页面渲染之前执行，调用定义的方法
    this.getInformantion()
  },
  methods: {//编写具体的方法
    getStudentScore() {
      axios.get("http://192.168.43.154:8082/studentscore",{
        params:{
          sname: this.information[0].sname,
        }
      })
        .then(response => {
          this.score = response.data
          console.log(this.score)
        })
        .catch(error => {

        })//请求失败执行catch方法
    },
    getInformantion(){
      //2.使用axios发送ajax请求
      //axios.提交方式(“请求s接口路径”).then(箭头函数).catch(箭头函数|)
      axios.get("http://192.168.43.154:8082/sa/inform")
        .then(response => {
          //response就是请求后返回的数据，response可以任意取名
          // console.log(response)
          //通过response获取具体数据，赋值给定义空数组
          this.information = response.data
          console.log(this.information)

        })//请求成功执行then方法
        .catch(error => {

        })//请求失败执行catch方法
    }
  },
}
</script>

<style scoped>
.content_right{
  width: 1344px;
  height: 666px;
  position: absolute;
  left: 190px;
  top: 85px;
  background-color: #ffffff;
  /*border: 1px solid black;*/
}
.control_right_top{
  width: 1343px;
  height: 80px;
  margin-bottom: -10px;

  /*border: 1px solid black;*/
}
.content_table table{
  width: 1200px;
  height: 520px;
  text-align: center;
  margin-left: 70px;
  margin-top: -20px;
  border: 1px solid black;
}
</style>
