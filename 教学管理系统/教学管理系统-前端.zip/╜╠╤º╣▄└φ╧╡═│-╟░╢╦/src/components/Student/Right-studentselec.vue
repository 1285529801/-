<template>
  <div class="content_right">
    <div class="control_right_top">
      <div style="position: relative;top:15px;left: 10px">
        <el-button type="primary" @click="dialogTableVisible = true">我的课程信息</el-button>
      </div>
      <hr style="width: 100%; margin-top: 86px" >
    </div>

<!--=============课程信息================-->
    <el-dialog title="我的课程信息" :visible.sync="dialogTableVisible">
      <el-button type="primary" @click="SelectMyCourse">查询信息</el-button>
      <el-table :data="mycourse" :row-class-name="tableRowClassName">
        <el-table-column property="cname" label="课程名" width="200"></el-table-column>
        <el-table-column property="teacher" label="任课老师" width="200"></el-table-column>
        <el-table-column property="classroom" label="上课地点" width="200"></el-table-column>
        <el-table-column property="" label="退选" >
          <template slot-scope="scope">
            <el-button type="danger" icon="el-icon-delete" circle @click.native.prevent="Tuicourse(scope.row)"></el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-dialog>

    <hr style="width: 100%">
    <div class="content_table">
      <el-table :data="course" height="540" :row-class-name="tableRowClassName" >
        <el-table-column property="" label="" width="60"></el-table-column>
        <el-table-column property="cno" label="课程号" width="120"></el-table-column>
        <el-table-column property="cname" label="课程名" width="120"></el-table-column>
        <el-table-column property="tno" label="教师工号" width="120"></el-table-column>
        <el-table-column property="teacher" label="任课教师" width="120"></el-table-column>
        <el-table-column property="period" label="学时" width="120"></el-table-column>
        <el-table-column property="classtime" label="上课时间" width="120"></el-table-column>
        <el-table-column property="classroom" label="上课地点" width="120"></el-table-column>
        <el-table-column property="cname" label="课程名" width="120"></el-table-column>
        <el-table-column property="tno" label="教师工号" width="120"></el-table-column>
        <el-table-column  width="120" label="操作">
          <template slot-scope="scope">
            <el-button type="danger" @click.native.prevent="SelectCourse(scope.row)">选修</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
  </div>
</template>

<script>
import axios from 'axios'
export default {
  name: 'Right-studentselec',
  data(){
    return{
      course: [],
      information:[],
      mycourse:[],
      dialogTableVisible: false,
    }
  },
  created () {//页面渲染之前执行，调用定义的方法
    //3.调用定义的方法
    this.getInformantion();
    this.getUserCourse()
    this.SelectMyCourse()
  },

  methods: {//编写具体的方法
    getUserCourse () {
      axios.get("http://192.168.43.154:8082/course/all").then(response => {
          this.course = response.data
          console.log(this.course)
        })
        .catch(error => {
        })

    },
    // SelectCourse学生选课
    SelectCourse(row) {
      console.log('被点击了');
      this.index = row.row_index;
      console.log(row);
      console.log(this.index);
      axios.get("http://192.168.43.154:8082/course/select",{
        params:{
          sno: this.information[0].sno,
          cno: this.course[this.index].cno,
          cname:this.course[this.index].cname
        }
      })
        .then(response => {
            console.log(response.data);
            alert("选课成功")
            window.location.href='student.html'
        })
        .catch(error => {

        })//请求失败执行catch方法
    },

    // SelectMyCourse获取我的课表
    SelectMyCourse(){
      axios.get("http://192.168.43.154:8082/course/mycourse",{
        params:{
          sname: this.information[0].sname,
        }
      }).then(response => {
          this.mycourse = response.data
          console.log(this.mycourse)
        })
        .catch(error => {

        })//请求失败执行catch方法
    },
    getInformantion(){
      axios.get("http://192.168.43.154:8082/sa/inform")
        .then(response => {
          this.information = response.data
          console.log(this.information)

        })
        .catch(error => {
        })
    },
    Tuicourse(row){
      console.log('被点击了');
      this.index = row.row_index;
      console.log(row);
      axios.get("http://192.168.43.154:8082/course/tui",{
        params:{
          sno:this.information[0].sno,
          cno:this.mycourse[this.index].cno
        },
      }).then(response => {
          this.course = response.data
          console.log(this.course)
          alert("退选课程成功")
          window.location.href='student.html'
        })
        .catch(error => {
        })
    },
    //获取行的下标index
    tableRowClassName({row, rowIndex}) {
      row.row_index = rowIndex;
    },

  },
}
</script>

<style scoped>
.content_right{
  width: 1344px;
  height: 666px;
  position: absolute;
  left: 190px;
  top: 85px;
  background-color: white;
}
.control_right_top{
  width: 1336px;
  height: 80px;
  margin-bottom: -10px;

  /*border: 1px solid black;*/
}
.content_table table{
  width: 1200px;
  height: 500px;
  text-align: center;
  margin-left: 80px;
  /*border: 1px solid black;*/
}
</style>
