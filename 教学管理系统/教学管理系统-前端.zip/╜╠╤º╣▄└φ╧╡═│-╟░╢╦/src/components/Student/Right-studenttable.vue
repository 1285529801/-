<template>
  <div class="content_right">
    <div class="control_right_top">
      <el-calendar>
        <!-- 这里使用的是 2.5 slot 语法，对于新项目请使用 2.6 slot 语法-->
        <template
          slot="dateCell"
          slot-scope="{date, data}">
          <p :class="data.isSelected ? 'is-selected' : ''">
            {{ data.day.split('-').slice(1).join('-') }} {{ data.isSelected ? '✔️' : ''}}
          </p>
        </template>
      </el-calendar>
    </div>
  </div>
</template>

<script>
export default {
  name: 'Right-studenttable'
}
</script>

<style scoped>
.content_right{
  width: 1344px;
  height: 666px;
  position: absolute;
  left: 190px;
  top: 85px;
  background-color: white;
}
.control_right_top{
  width: 1336px;
  height: 80px;
  margin-bottom: -10px;

  /*border: 1px solid black;*/
}
.content_table table{
  width: 1200px;
  height: 500px;
  text-align: center;
  margin-left: 80px;
  /*border: 1px solid black;*/
}
.is-selected {
  color: #1989FA;
}
</style>
