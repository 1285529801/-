<template>
  <div class="content-left">
    <el-col :span="24">
      <el-menu
        default-active="2"
        class="el-menu-vertical-demo"
        @open="handleOpen"
        @close="handleClose">

        <router-link to="/RightStudentselec">
        <el-menu-item index="1">
          <i class="el-icon-menu"></i>
            <span slot="title">选课</span>
        </el-menu-item>
        </router-link>

        <router-link to="/RightStudenttable">
        <el-menu-item index="2">
          <i class="el-icon-document"></i>
          <span slot="title">课程表</span>
        </el-menu-item>
        </router-link>

        <router-link to="/RightStudentscore">
          <el-menu-item index="3">
            <i class="el-icon-coin"></i>
            <span slot="title">成绩</span>
          </el-menu-item>
        </router-link>

      </el-menu>
    </el-col>

  </div>


</template>

<script>
export default {
  name: 'Left-teacher'
}
</script>

<style scoped>
.content-left{
  width: 190px;
  height: 667px;
  background-image: linear-gradient(to right, #9db6ea,lightskyblue);
}

a {
  text-decoration: none;
}
</style>
