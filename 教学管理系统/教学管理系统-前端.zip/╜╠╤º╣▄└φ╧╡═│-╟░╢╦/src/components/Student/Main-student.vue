<template>
  <div>
    <topStudent></topStudent>
    <leftStudent></leftStudent>
    <rightStudentmain></rightStudentmain>

    <transition>
      <keep-alive>
        <router-view></router-view>
      </keep-alive>
    </transition>
  </div>
</template>

<script>
import topStudent from './Top-student'
import leftStudent from './Left-student'
import rightStudentmain from './Right-studentmain'
// import rightStudentscore from './Right-studentscore'
// import rightStudentselec from './Right-studentselec'
// import rightStudenttable from './Right-studenttable'
export default {
  name: 'Main-student',
  components:{
    topStudent,
    leftStudent,
    rightStudentmain,
  }
}
</script>

<style scoped>

</style>
