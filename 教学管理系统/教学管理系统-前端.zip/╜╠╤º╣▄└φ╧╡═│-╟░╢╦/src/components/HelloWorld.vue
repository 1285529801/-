<template>
  <div class="hello">
    <h2>{{ user[0].id }}</h2>

  </div>
</template>

<script>
import axios from 'axios'

export default {
  name: 'HelloWorld',
  data() {
    return {
      user: [],
    }
  },
  created(){//页面渲染之前执行，调用定义的方法
    //3.调用定义的方法
    this.getUserUser()
  },
  methods:{//编写具体的方法
    getUserUser(){
      //2.使用axios发送ajax请求
      //axios.提交方式(“请求s接口路径”).then(箭头函数).catch(箭头函数|)
      axios.get("http://10.152.244.63:8082/manger/all")
        .then(response=>{
          //response就是请求后返回的数据，response可以任意取名
          // console.log(response)
          //通过response获取具体数据，赋值给定义空数组
          this.user=response.data
          console.log(this.user)

        })//请求成功执行then方法
        .catch(error=>{

        })//请求失败执行catch方法
    }
  }

}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h1, h2 {
  font-weight: normal;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
