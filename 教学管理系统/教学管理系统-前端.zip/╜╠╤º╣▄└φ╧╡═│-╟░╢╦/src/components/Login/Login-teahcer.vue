<template>
  <div class="container">
    <div class="login-wrapper">
      <div class="header">教师登录</div>
      <el-form :model="ruleForm" :rules="rules" ref="ruleForm" label-width="10px" class="demo-ruleForm">
        <!--        职工号-->
        <el-form-item prop="tno">
          <el-input v-model="ruleForm.tno" class="input-item " suffix-icon="el-icon-user-solid" ></el-input>
        </el-form-item>
        <br>
        <!--        教师姓名-->
        <el-form-item prop="tname" >
          <el-input v-model="ruleForm.tname" class="input-item "  show-password></el-input>
        </el-form-item>
        <!--        按钮-->
        <el-form-item class="btn">
          <el-button type="primary" @click="login" class="anu">提交</el-button>
          <el-button type="info" @click="resetForm('ruleForm')" class="anu">重置</el-button>
        </el-form-item>
      </el-form>
    </div>
  </div>
</template>

<script>
import axios from 'axios'
export default {
  name: 'Login-teahcer',
  data() {
    return {
      // 表单数据对象
      ruleForm: {
        tno: '',
        tname: '',
      },
      // 验证对象
      rules: {
        tno: [
          {required: true, message: '请输入tno', trigger: 'blur'},
        ],
        tname:[
          {required: true, message: '请输入名字', trigger: 'blur'},
        ]
      }
    }
  },
  methods:{//编写具体的方法
    resetForm(formName) {
      this.$refs[formName].resetFields();
    },
    login:function (){
      axios.get("http://192.168.43.154:8082/tea/login",{
        params:{
          tno: this.ruleForm.tno,
          tname: this.ruleForm.tname
        }
      }).then(response=>{
        console.log(response.data);
        if(response.data=="0"){
          alert("老师不存在");
        }
        else if(response.data=="1"){
          alert("登录成功");
          window.location.href='teacher.html'
        }
      })
    }
  }
}
</script>

<style scoped>
* {
  margin: 0;
  padding: 0;
}
html {
  height: 100%;
}
body {
  height: 100%;
}
.container {
  height: 606px;
  background-image: linear-gradient(to right, #fbc2eb, #a6c1ee);
}
.login-wrapper {
  background-color: #fff;
  width: 358px;
  height: 588px;
  border-radius: 15px;
  padding: 0 50px;
  position: relative;
  left: 50%;
  top: 36%;
  transform: translate(-50%, -50%);
}
.header {
  font-size: 38px;
  font-weight: bold;
  text-align: center;
  line-height: 200px;
  letter-spacing:4px;
}
.input-item {
  display: block;
  width: 100%;
  margin-bottom: 20px;
  border: 0;
  padding: 1px;
  font-size: 15px;
  outline: none;
  font-size: 15px;
}
.input-item:placeholder {
  text-transform: uppercase;
}
.btn {
  text-align: center;
  padding: 10px;
  width: 100%;
  margin-top: 20px;
  color: #fff;
}
.msg {
  text-align: center;
  line-height: 88px;
}
a {
  text-decoration-line: none;
  color: #abc1ee;
}
.anu{
  width: 160px;
  height: 45px;
  margin-right: 6px;
}
</style>
