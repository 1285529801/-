<template>

  <body>
    <div class="container">
      <div class="login-wrapper">
        <div class="header">请选择登录身份</div>
        <div class="menu">

          <router-link to="/Login-manager" class="module" >
            <img src="../../assets/IMG/manager.png" class="photo" alt="">
            <p>教务处登录</p>
          </router-link>

          <router-link to="/Login-teacher" class="module" >
            <img src="../../assets/IMG/teacher.png" class="photo" alt="">
            <p>老师登录</p>
          </router-link>

          <router-link to="/Login-student" class="module">
            <img src="../../assets/IMG/student.png" class="photo" alt="">
            <p>学生登录</p>
          </router-link>
        </div>
      </div>
    </div>
    <div style="position: relative;top: -590px;left: 0px">
      <router-view></router-view>
    </div>
  </body>

</template>

<script>
import loginTeahcer from './Login-teahcer'
import loginManager from './Login-manager'
import loginStudent from './Login-student'
export default {
  name: 'Login-S',
  components:{
    loginTeahcer,
    loginManager,
    loginStudent
  }

}
</script>

<style scoped>
* {
  margin: 0;
  padding: 0;
}
html {
  height: 100%;
}
body {
  height: 100%;
}
.container {
  height: 753px;
  background-image: linear-gradient(to right, #fbc2eb, #a6c1ee);
  margin: 0;
  padding: 0;
}
.login-wrapper {
  background-color: #fff;
  width: 700px;
  height: 400px;
  border-radius: 15px;
  padding: 0 50px;
  position: relative;
  left: 50%;
  top: 49%;
  transform: translate(-50%, -50%);
}
.header {
  font-size: 35px;
  font-weight: bold;
  text-align: center;
  line-height: 150px;
  letter-spacing:2px;
  /*border: 1px solid black;*/
}
.menu{
  display: flex;
  flex-direction: row;
  justify-content: space-around;
  position: relative;
  left: 50%;
  top: 20%;
  transform: translate(-50%, -50%);
}
.photo{
  width: 90px;
  height: 90px;
  border-bottom: 1px solid black;
  text-align: center;
  line-height:80px;
}
.module{
  border: 1px solid black;
  text-align: center;
  letter-spacing:1px;
  border-radius: 5px;
  font-weight: bold;
  text-decoration: none;
  color: #2c3e50;
}
.module:hover{
  border: 1px solid #a6c1ee;
}

</style>
