<template>

</template>

<script>
export default {
  name: 'Bottom'
}
</script>

<style scoped>

</style>
