<template>
  <div class="content-left">
    <img src="img/e_01.jpg">
    <div class="left_1">
      <img src="img/left_01.png">
      <p>设备信息</p>
    </div>
    <div class="left_2">
      <img src="img/jiao.png">
      <p>所有设备</p>
    </div>
    <div class="left_2">
      <img src="img/jiao.png">
      <p>正常设备</p>
    </div>
    <div class="left_2">
      <img src="img/jiao.png">
      <p>异常设备</p>
    </div>
    <div class="left_2">
      <img src="img/jiao.png">
      <p>共享设备</p>
    </div>
    <div class="left_1">
      <img src="img/left_03.jpg">
      <p>设备接口</p>
    </div>
    <div class="left_1">
      <img src="img/left_02.png">
      <p>集成设备</p>
    </div>
    <div class="left_1">
      <img src="img/left_03.png">
      <p>设备厂商</p>
    </div>
    <div class="left_1">
      <img src="img/left_05.png">
      <p>设备型号</p>
    </div>
    <div class="left_1">
      <img src="img/left_06.png">
      <p>更多设备</p>
    </div>
  </div>
</template>

<script>
export default {
  name: 'Left'
}
</script>

<style scoped>

.content-left{
  width: 200px;
  height: 1000px;
  background-color: lightskyblue;
}
.content-left p{
  display: inline;
}
.left_1>p{
  color: black;
  line-height: 30px;
}
.left_2>p{
  color: white;
  line-height: 25px;
}
.left_2{
  margin-left: 30px;
}

</style>
