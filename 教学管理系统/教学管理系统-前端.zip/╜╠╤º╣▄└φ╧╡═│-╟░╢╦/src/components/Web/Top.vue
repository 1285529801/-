<template>
  <div class="head">
    <div class="head-left">
      <img src="img/logo.png">
    </div>
    <div class="head-right">
      <div class="head-right-top">
        <ul>
          <li>退出</li>
          <li><img src="img/dl.png"></li>
          <li>欢迎使用信息系统!</li>
          <li><img src="img/left_15.png"></li>
        </ul>
      </div>
      <div class="head-right-bottom">
        <ul>
          <li><a href="#"><img src="img/left_14.png"></a><p>系统管理</p></li>
          <li><a href="#"><img src="img/left_05.png"></a><p>数据分析</p></li>
          <li><a href="#"><img src="img/left_05.png"></a><p>设备管理</p></li>
          <li><a href="#"><img src="img/left_03.jpg"></a><p>数据同步</p></li>
          <li><a href="#"><img src="img/equi-icon2.png"></a><p>数据展示</p></li>
          <li><a href="#"><img src="img/equi-icon1.png"></a><p>数据采集</p></li>
        </ul>
      </div>
    </div>
  </div>

</template>

<script>
export default {
  name: 'Top'
}
</script>

<style scoped>
    *{
      padding: 10px;
      margin: -5px;
    }
    .head{
      height: 80px;
      width: 98.4%;
      margin: 0;
      background-color: cornflowerblue;
    }
    .head-left{
      height: 0px;
      width: 500px;
    }
    .head-left img {
      padding-top: 20px;
      padding-left: 20px;
      float: left;
    }
    .head-right-top{
      width: 600px;
      height: 20px;
      float: right;
      margin-right: 20px;
      margin-bottom: 3px;
    }
    .head-right-top>ul{
      margin: 0;
      padding: 0;
      list-style: none;
      margin-right: 20;
    }
    .head-right-top li{
      float: right;
      padding-left: 6px;
    }
    .head-right-top a{
      margin-left: 10px;
      text-decoration: none;
    }
    .head-right-bottom{
      height: 40px;
      width: 600px;
      float: right;
    }
    .head-right-bottom>ul{
      text-align: center;
      margin: 0;
      padding: 0;
      list-style-type: none;
      margin-right: 20px;
    }
    .head-right-bottom li{
      float: right;
      padding-left: 14px;
    }
    .head-right-bottom img{
      width: 25px;
      height: 25px;
    }.head-right-bottom p{
       color: white;
       font-size: 15px;
     }
</style>
