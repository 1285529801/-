<template>
  <div class="content_right">
    <div class="control_right_top">
      <img src="img/home.jpg">
      <span>当前位置&gt;&gt;设备管理&gt;&gt;设备信息&gt;&gt;所有设备&gt;&gt;</span>
      <hr style="width: 100%;">
    </div>
    <div class="content_right_content">
				<span><img src="img/left_14.png">&nbsp;搜索&nbsp;&nbsp;&nbsp;设备名称:<input type="text" placeholder="输入设备名称">&nbsp;&nbsp;设备类型:<select><option>计算机设备</option>
					<option>科学设备</option><option>软件设备</option><option>智能设备</option>
				</select>&nbsp;&nbsp;<button type="button">查询</button></span>
    </div>
    <div class="content_table">
      <table>
        <tr>
          <td><input type="checkbox">全选</input></td>
          <td>设备类型</td>
          <td>设备名称</td>
          <td>设备编号</td>
          <td>创建日期</td>
          <td>设备状态</td>
          <td>是否共享</td>
          <td>修改设备</td>
        </tr>
        <tr>
          <td><input type="checkbox"></td>
          <td>网络摄像头</td>
          <td>计算机网络设备</td>
          <td>0001</td>
          <td>2021/10/30</td>
          <td style="color: red;">设备异常</td>
          <td><img src="img/device-1.png" /></td>
          <td><img src="img/share-1.png" /></td>
          <td><img src="img/equi-icon2.png" /></td>
        </tr>
        <tr>
          <td><input type="checkbox"></td>
          <td>智能终端</td>
          <td>集成开发版设备</td>
          <td>0010</td>
          <td>2021/10/30</td>
          <td style="color: green;">设备正常</td>
          <td><img src="img/device-1.png" /></td>
          <td><img src="img/share-1.png" /></td>
          <td><img src="img/equi-icon2.png" /></td>
        </tr>
        <tr>
          <td><input type="checkbox"></td>
          <td>移动电话</td>
          <td>算法与数据设备</td>
          <td>0011</td>
          <td>2021/10/30</td>
          <td style="color: green;">设备正常</td>
          <td><img src="img/device-1.png" /></td>
          <td><img src="img/share-1.png" /></td>
          <td><img src="img/equi-icon2.png" /></td>
        </tr>
        <tr>
          <td><input type="checkbox"></td>
          <td>平板电脑</td>
          <td>IDE开发设备</td>
          <td>0100</td>
          <td>2021/10/30</td>
          <td style="color: green;">设备正常</td>
          <td><img src="img/device-1.png" /></td>
          <td><img src="img/share-1.png" /></td>
          <td><img src="img/equi-icon2.png" /></td>
        </tr>
        <tr>
          <td><input type="checkbox"></td>
          <td>STM32开发班</td>
          <td>底层架构设备</td>
          <td>0101</td>
          <td>2021/10/30</td>
          <td style="color: green;">设备正常</td>
          <td><img src="img/device-1.png" /></td>
          <td><img src="img/share-1.png" /></td>
          <td><img src="img/equi-icon2.png" /></td>
        </tr>
        <tr>
          <td><input type="checkbox"></td>
          <td>树莓派开发板</td>
          <td>链路层设备</td>
          <td>0110</td>
          <td>2021/10/30</td>
          <td style="color: green;">设备正常</td>
          <td><img src="img/device-1.png" /></td>
          <td><img src="img/share-1.png" /></td>
          <td><img src="img/equi-icon2.png" /></td>
        </tr>
      </table>
      <span><img src="img/tj.jpg">|<img src="img/sc.jpg"></span>
      <span style="float: right; margin-right: 200px;"><button type="button">首页</button>
					<button type="button" style="border: none; background: none; font-weight: bold;">1</button>
					<button type="button" style="border: none; background: none; font-weight: bold;">2</button>
					<button type="button" style="border: none; background: none; font-weight: bold;">3</button>
					<button type="button" style="border: none; background: none; font-weight: bold;">...</button>
					<button type="button">下一页</button>
					<button type="button">尾页</button>
				</span>
    </div>
  </div>

</template>

<script>
export default {
  name: 'Right'
}
</script>

<style scoped>

.content_right{
  position: absolute;
  left: 210px;
  top: 107px;

}
.control_right_top{
  width: 1300px;
  height: 30px;
  margin-bottom: 2px;
}
.content_table table{
  width: 1200px;
  height: 500px;
  text-align: center;
}

</style>
