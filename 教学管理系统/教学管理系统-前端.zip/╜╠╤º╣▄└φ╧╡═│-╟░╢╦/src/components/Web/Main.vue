<template>
  <div>
    <Top></Top>
    <left></left>
    <right></right>
  </div>

</template>

<script>
import left from './Left'
import right from './Right'
import Top from './Top'
export default {
  name: 'Main',

  components:{
    Top,
    left,
    right
  },

}
</script>

<style scoped>

</style>
