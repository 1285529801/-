<template>

</template>

<script>
export default {
  name: 'Right-teachermain'
}
</script>

<style scoped>

</style>
