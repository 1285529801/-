<template>
  <div class="content_right">
    <div class="control_right_top">
      <h2 style="margin-left: 30px">全部学生</h2>
      <div style="margin-left: 1075px;margin-top: -48px;margin-bottom: 10px">
        <el-button type="primary" @click="outerVisible = true" size="40">打印学生表  /  成绩录入</el-button>
      </div>
      <hr style="width: 100%;margin-top: 48px">
    </div>

    <el-dialog title="学生信息" :visible.sync="outerVisible">
<!--      ================内层================-->
            <el-dialog
              width="35%"
              title="学生成绩录入"
              :visible.sync="innerVisible"
              append-to-body>
              <el-form :model="form" ref="form">
                <el-form-item label="学号" :label-width="formLabelWidth">
                  <el-input v-model="form.sno" autocomplete="off"></el-input>
                </el-form-item>
                <el-form-item label="课程号" :label-width="formLabelWidth">
                  <el-input v-model="form.cno" autocomplete="off"></el-input>
                </el-form-item>
                <el-form-item label="成绩" :label-width="formLabelWidth">
                  <el-input v-model="form.score" autocomplete="off"></el-input>
                </el-form-item>
              </el-form>
              <div slot="footer" class="dialog-footer">
                <el-button @click="innerVisible = false">取 消</el-button>
                <el-button type="primary" @click="interscore">确 定</el-button>
              </div>
            </el-dialog>
      <!--      ================内层================-->
<!--     =============== 外层是打印选了该老师上的课程的学生===========-->
      <el-table :data="tstudent">-->
                <el-table-column property="sno" label="学生号" width="320"></el-table-column>
                <el-table-column property="sname" label="学生姓名" width="320"></el-table-column>
                <el-table-column property="classes" label="所在班级"></el-table-column>
              </el-table>
        <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="getteacherstudent">打印</el-button>

        <el-button type="primary" @click="innerVisible = true">成绩录入</el-button>
        <el-button @click="outerVisible = false">取 消</el-button>
      </div>
    </el-dialog>

<!--    ==========================-->

    <div class="content_table" style="margin-top: 20px">
      <el-table :data="student" height="560" :row-class-name="tableRowClassName" @row-click="getRow">
        <el-table-column property="" label="" width="260"></el-table-column>
        <el-table-column property="sno" label="学号" width="420"></el-table-column>
        <el-table-column property="sname" label="姓名" width="420"></el-table-column>
        <el-table-column property="classes" label="所属班级" width="220"></el-table-column>
      </el-table>

    </div>
  </div>
</template>

<script>
import axios from 'axios'
export default {
  name: 'Right-TM',
  data() {
    return {
      student: [],
      tstudent:[],
      information:[],
      innerFormVisible: false,
      outerVisible: false,
      innerVisible: false,
      form: {
        sno:'',
        sname:'',
        score:'',
      },
      formLabelWidth: '90px'
    }
  },
  created(){//页面渲染之前执行，调用定义的方法
    //3.调用定义的方法
    this.getInformantion();
    this.getUserStudent()

  },
  methods:{//编写具体的方法
    getUserStudent(){
      //2.使用axios发送ajax请求
      //axios.提交方式(“请求s接口路径”).then(箭头函数).catch(箭头函数|)
      axios.get("http://192.168.43.154:8082/sa/stu")
        .then(response=>{
          //response就是请求后返回的数据，response可以任意取名
          // console.log(response)
          //通过response获取具体数据，赋值给定义空数组
          this.student=response.data
          console.log(this.student)

        })//请求成功执行then方法
        .catch(error=>{
        })//请求失败执行catch方法
    },
    getInformantion () {
      axios.get("http://192.168.43.154:8082/tea/information")
        .then(response => {
          this.information = response.data
          console.log(this.information)
        })
        .catch(error => {
        })
    },
    getteacherstudent(){
      axios.get("http://192.168.43.154:8082/stu/tea",{
        params:{
          tname:this.information[0].tname
        }
      })
        .then(response=>{
          this.tstudent=response.data
          console.log(this.tstudent)
        })
        .catch(error=>{
        })
    },
    interscore(){
      axios.get("http://192.168.43.154:8082/interscore",{
        params:{
          cno:this.form.cno,
          sno:this.form.sno,
          score:this.form.score,
        }
      })
        .then(response=>{

          this.student=response.data
          console.log(this.student)
          alert("修改成功");
          window.location.href='teacher.html'
        })//请求成功执行then方法
        .catch(error=>{
        })
    },
  }
}
</script>

<style scoped>
.content_right{
  position: absolute;
  left: 190px;
  top: 85px;
  /*border: 1px solid black;*/
}
.control_right_top{
  width: 1342px;
  height: 60px;
  margin-bottom: -25px;
  /*border: 1px solid #5e87d7;*/
}
.content_table table{
  width: 1200px;
  height: 500px;
  text-align: center;
  margin-left: 80px;
  /*border: 1px solid #ec1616;*/
}
</style>
