<template>
  <div class="content_right">
    <div class="control_right_top">
      <div style="margin-top: 15px;margin-left: 20px">
        <el-button type="primary" @click="dialogFormVisible = true">增加课程</el-button>
        <el-button type="primary" @click="adialogFormVisible = true">修改课程</el-button>
      </div>
      <hr style="width: 100%; margin-top: 90px">
    </div>

    <el-dialog title="增加课程信息" :visible.sync="dialogFormVisible">
      <el-form :model="form">
        <el-form-item label="课程ID" :label-width="formLabelWidth">
          <el-input v-model="form.cno" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="课程名字" :label-width="formLabelWidth">
          <el-input v-model="form.cname" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="课程学时" :label-width="formLabelWidth">
          <el-input v-model="form.period" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="上课时间" :label-width="formLabelWidth">
          <el-input v-model="form.classtime" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="上课地点" :label-width="formLabelWidth">
          <el-input v-model="form.classroom" autocomplete="off"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogFormVisible = false">取 消</el-button>
        <el-button type="primary" @click="Addnotes">确 定</el-button>
      </div>
    </el-dialog>

    <el-dialog title="修改课程信息" :visible.sync="adialogFormVisible">
      <el-form :model="forms">
        <el-form-item label="课程ID" :label-width="formLabelWidth">
          <el-input v-model="forms.cno" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="课程名字" :label-width="formLabelWidth">
          <el-input v-model="forms.cname" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="课程学时" :label-width="formLabelWidth">
          <el-input v-model="forms.period" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="上课时间" :label-width="formLabelWidth">
          <el-input v-model="forms.classtime" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="上课地点" :label-width="formLabelWidth">
          <el-input v-model="forms.classroom" autocomplete="off"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="adialogFormVisible = false">取 消</el-button>
        <el-button type="primary" @click="Updatecourse">确 定</el-button>
      </div>
    </el-dialog>

    <div class="content_table">
      <el-table :data="course" height="540" :row-class-name="tableRowClassName" >
        <el-table-column property="" label="" width="60"></el-table-column>
        <el-table-column property="cno" label="课程号" width="120"></el-table-column>
        <el-table-column property="cname" label="课程名" width="120"></el-table-column>
        <el-table-column property="tno" label="教师工号" width="120"></el-table-column>
        <el-table-column property="teacher" label="任课教师" width="120"></el-table-column>
        <el-table-column property="period" label="学时" width="120"></el-table-column>
        <el-table-column property="classtime" label="上课时间" width="120"></el-table-column>
        <el-table-column property="classroom" label="上课地点" width="120"></el-table-column>
        <el-table-column property="cname" label="课程名" width="120"></el-table-column>
        <el-table-column property="tno" label="教师工号" width="120"></el-table-column>
        <el-table-column  width="120" label="操作">
          <template slot-scope="scope">
            <el-button type="danger" @click.native.prevent="Deletecourse(scope.row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
  </div>
</template>

<script>
import axios from 'axios'
export default {
  name: 'Right-TS',
  data () {
    return {
      course: [],
      information:[],
      dialogTableVisible: false,
      dialogFormVisible: false,
      adialogFormVisible:false,
      form: {
        cno:'',
        cname:'',
        period:'',
        classtime:'',
        classroom:'',
      },
      forms: {
        cno:'',
        cname:'',
        period:'',
        classtime:'',
        classroom:'',
      },
      formLabelWidth: '120px'
    }
  },
  created () {//页面渲染之前执行，调用定义的方法
    //3.调用定义的方法
    this.getUserCourse()
    this.getInformantion ()
  },
  methods: {//编写具体的方法
    getUserCourse () {
      //2.使用axios发送ajax请求
      //axios.提交方式(“请求s接口路径”).then(箭头函数).catch(箭头函数|)
      axios.get("http://192.168.43.154:8082/course/all")
        .then(response => {
          //response就是请求后返回的数据，response可以任意取名
          // console.log(response)
          //通过response获取具体数据，赋值给定义空数组
          this.course = response.data
          console.log(this.course)
        })
        .catch(error => {
        })
    },
    getInformantion () {
      axios.get("http://192.168.43.154:8082/tea/information")
        .then(response => {
          this.information = response.data
          console.log(this.information)
        })
        .catch(error => {
        })
    },
    Addnotes(){
      axios.get("http://192.168.43.154:8082/notes/add",{
        params:{
          cno:this.form.cno,
          cname:this.form.cname,
          tno:this.information[0].tno,
          teacher:this.information[0].tname,
          period:this.form.period,
          classtime:this.form.classtime,
          classroom:this.form.classtime,
        }
      })
        .then(response => {
          this.course = response.data
          console.log(this.course)
          alert("增加申请提交成功")
          window.location.href='teacher.html'
        })
        .catch(error => {
        })
    },
    Updatecourse(){
      axios.get("http://192.168.43.154:8082/notes/update",{
        params:{
          cname: this.forms.cname,
          cno:this.forms.cno,
          tno:this.information[0].tno,
          teacher:this.information[0].tname,
          classtime:this.forms.classtime,
          classroom:this.forms.classtime,
          period:this.forms.period,
        },

      })
        .then(response => {
          this.course = response.data
          console.log(this.course)
          alert("修改申请提交成功")
          window.location.href='teacher.html'
        })
        .catch(error => {
        })
    },
    Deletecourse(row){
      console.log('被点击了');
      this.index = row.row_index;
      console.log(row);
      console.log(this.index);
      axios.get("http://192.168.43.154:8082/notes/del",{
        params:{
          cname: this.course[this.index].cname,
          cno:this.course[this.index].cno,
          teacher:this.information[0].tname,
          tno:this.information[0].tno,
          period:this.course[this.index].period,
          classtime:this.course[this.index].classtime,
          classroom:this.course[this.index].classroom
        },

      })
        .then(response => {
          this.course = response.data
          console.log(this.course)
          alert("删除申请提交成功")
          window.location.href='teacher.html'
        })
        .catch(error => {
        })
    },

    //获取行的下标index
    tableRowClassName({row, rowIndex}) {
      row.row_index = rowIndex;
    },
  },
}
</script>
<style scoped>
.content_right{
  position: absolute;
  left: 190px;
  top: 85px;
  width: 1343px;
  height: 666px;
  /*border: 1px solid #c91616;*/
}
.control_right_top{
  width: 1340px;
  height: 90px;
  margin-bottom: -10px;
  /*border: 1px solid black;*/
}
.content_table table{
  width: 1200px;
  height: 500px;
  text-align: center;
  margin-left: 80px;
  /*border: 1px solid black;*/
}
</style>
