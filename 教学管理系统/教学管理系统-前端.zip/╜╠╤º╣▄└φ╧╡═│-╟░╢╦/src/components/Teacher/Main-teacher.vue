<template>
  <div>
    <topTeacher></topTeacher>
    <leftTeacher></leftTeacher>
    <RightTeachermain></RightTeachermain>
    <transition>
      <keep-alive>
        <router-view></router-view>
      </keep-alive>
    </transition>
  </div>

</template>

<script>
 import topTeacher from './Top-teacher'
 import leftTeacher from './Left-teacher'
 import RightTeachermain from './Right-teachermain'
 import RightTeacherCoursemg from './Right-teacher-coursemg'
 import RightTeacherCourseset from './Right-teacher-courseset'
export default {
  name: 'Main-T',

  components:{
    topTeacher,
    leftTeacher,
    RightTeachermain,
    RightTeacherCoursemg,
    RightTeacherCourseset

  }
}
</script>

<style scoped>

</style>
