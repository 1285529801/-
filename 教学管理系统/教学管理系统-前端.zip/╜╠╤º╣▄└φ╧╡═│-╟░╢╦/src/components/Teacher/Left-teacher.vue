<template>
  <div class="content-left">
    <el-col :span="24">
      <el-menu
        default-active="2"
        class="el-menu-vertical-demo"
        @open="handleOpen"
        @close="handleClose">
        <router-link to="/RightTeacherCourseset">
          <el-menu-item index="1">
            <i class="el-icon-s-tools"></i>
            <span slot="title">课程设置</span>
          </el-menu-item>
        </router-link>
        <router-link to="/RightTeacherCoursemg">
          <el-menu-item index="2">
            <i class="el-icon-menu"></i>
            <span slot="title">课程管理</span>
          </el-menu-item>
        </router-link>
      </el-menu>
    </el-col>
  </div>
</template>

<script>
export default {
  name: 'Left-T'
}
</script>

<style scoped>
.content-left{
  width: 190px;
  height: 667px;
  background-image: linear-gradient(to right, #9db6ea,lightskyblue);
}
a {
  text-decoration: none;
}

</style>
